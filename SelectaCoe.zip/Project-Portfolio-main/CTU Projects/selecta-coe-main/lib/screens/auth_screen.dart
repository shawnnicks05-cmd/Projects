// lib/screens/auth_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/app_store.dart';
import '../models/models.dart';
import '../theme.dart';
import '../theme_provider.dart';
import '../widgets/pill_header.dart';
import '../widgets/app_logo.dart';
import 'forgot_password_screen.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  final GlobalKey<_LoginFormState> _loginFormKey = GlobalKey<_LoginFormState>();
  String? _pendingAutoFillEmail;
  String? _pendingAutoFillPassword;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _tab.addListener(_onTabChanged);
  }

  @override
  void dispose() {
    _tab.removeListener(_onTabChanged);
    _tab.dispose();
    super.dispose();
  }

  void _onTabChanged() {
    print('Tab changed to index: ${_tab.index}');
    print(
        'Pending auto-fill data: email=$_pendingAutoFillEmail, password=$_pendingAutoFillPassword');
    print(
        'Login form key current state: ${_loginFormKey.currentState != null}');

    // If we have pending auto-fill data and switched to login tab (index 0)
    if (_pendingAutoFillEmail != null &&
        _pendingAutoFillPassword != null &&
        _tab.index == 0) {
      print('Attempting auto-fill...');
      // Store data locally to avoid state access issues
      final email = _pendingAutoFillEmail;
      final password = _pendingAutoFillPassword;
      
      // Small delay to ensure tab animation is complete
      Future.delayed(const Duration(milliseconds: 200), () {
        print(
            'Delayed auto-fill attempt - mounted: $mounted, formState: ${_loginFormKey.currentState != null}');
        if (mounted && _loginFormKey.currentState != null && email != null && password != null) {
          print('Calling autoFillCredentials with: $email, $password');
          _loginFormKey.currentState!.autoFillCredentials(email, password);
          // Clear pending data
          if (mounted) {
            setState(() {
              _pendingAutoFillEmail = null;
              _pendingAutoFillPassword = null;
            });
          }
          print('Auto-fill completed and pending data cleared');
        } else {
          print('Auto-fill failed - mounted or form state null');
        }
      });
    }
  }

  void _handleAutoFill(String email, String password) {
    print('Auto-fill handler called with: email=$email, password=$password');

    // Store pending data before switching tabs
    setState(() {
      _pendingAutoFillEmail = email;
      _pendingAutoFillPassword = password;
    });

    // Always switch to login tab and wait for it to complete
    _tab.animateTo(0);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
      appBar: PillHeader(
        title: 'SELECTA-COE',
        leadingIcon: Icons.school,
        onLeadingTap: null,
        actions: [
          Consumer<ThemeProvider>(
            builder: (context, themeProvider, child) {
              return IconButton(
                onPressed: themeProvider.toggleTheme,
                tooltip: themeProvider.isDarkMode
                    ? 'Switch to light mode'
                    : 'Switch to dark mode',
                icon: Icon(themeProvider.isDarkMode
                    ? Icons.light_mode
                    : Icons.dark_mode),
              );
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 32),
                  // Logo
                  Row(
                    children: [
                      const AppLogo(size: 80),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'SELECTA-COE',
                            style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.w800,
                              color: Theme.of(context).colorScheme.onSurface,
                              letterSpacing: 7,
                            ),
                          ),
                          Text(
                            '   Student Electronic Ledger',
                            style: TextStyle(
                                fontSize: 13,
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurface
                                    .withOpacity(0.6),
                                fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),
                  // Form
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surface,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.08),
                          blurRadius: 20,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        // Tab Bar
                        Container(
                          decoration: BoxDecoration(
                            color: Theme.of(context)
                                .colorScheme
                                .surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: TabBar(
                            controller: _tab,
                            labelColor: Theme.of(context).colorScheme.primary,
                            unselectedLabelColor: Theme.of(context)
                                .colorScheme
                                .onSurface
                                .withOpacity(0.6),
                            indicator: const UnderlineTabIndicator(
                              borderSide: BorderSide(
                                color: Colors.transparent,
                                width: 0,
                              ),
                            ),
                            labelStyle:
                                const TextStyle(fontWeight: FontWeight.w600),
                            tabs: const [
                              Tab(text: 'Sign In'),
                              Tab(text: 'Create Account'),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 480,
                          child: TabBarView(
                            controller: _tab,
                            children: [
                              _LoginForm(key: _loginFormKey),
                              _RegisterForm(
                                tabController: _tab,
                                onAutoFill: _handleAutoFill,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _LoginForm extends StatefulWidget {
  const _LoginForm({super.key});

  @override
  State<_LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<_LoginForm> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _emailFocus = FocusNode();
  final _passFocus = FocusNode();
  bool _obscure = true;
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _email.dispose();
    _pass.dispose();
    _emailFocus.dispose();
    _passFocus.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    // Demo: any password works
    final ok = await AppStore().login(_email.text.trim(), _pass.text.trim());
    if (!mounted) return;
    if (ok) {
      Navigator.pushReplacementNamed(context, '/home');
    } else {
      setState(() {
        _error = 'No account found with that email or incorrect password.';
        _loading = false;
      });
    }
  }

  void autoFillCredentials(String email, String password) {
    print('autoFillCredentials called with: email=$email, password=$password');
    print('Current email text before: ${_email.text}');
    print('Current password text before: ${_pass.text}');

    setState(() {
      _email.text = email;
      _pass.text = password;
    });

    print('Current email text after: ${_email.text}');
    print('Current password text after: ${_pass.text}');
    print('Auto-fill credentials set successfully');
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Welcome!',
              style: TextStyle(
                  letterSpacing: 3,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: Theme.of(context).colorScheme.onSurface)),
          SizedBox(height: 4),
          Text('Sign in to your account',
              style: TextStyle(
                  fontSize: 13,
                  color: Theme.of(context)
                      .colorScheme
                      .onSurface
                      .withOpacity(0.7))),
          SizedBox(height: 24),
          TextFormField(
            focusNode: _emailFocus,
            textInputAction: TextInputAction.next,
            onFieldSubmitted: (_) =>
                FocusScope.of(context).requestFocus(_passFocus),
            style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
            controller: _email,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              labelText: 'Email address',
              prefixIcon: Icon(Icons.email_outlined, size: 18),
            ),
          ),
          const SizedBox(height: 12),
          TextFormField(
            focusNode: _passFocus,
            textInputAction: TextInputAction.done,
            onFieldSubmitted: (_) => _login(),
            // Use theme-aware text color (black in light mode, white in dark mode).
            style: TextStyle(color: AppTheme.getTextPrimary(context)),
            controller: _pass,
            obscureText: _obscure,
            decoration: InputDecoration(
              labelText: 'Password',
              prefixIcon: const Icon(Icons.lock_outline, size: 18),
              suffixIcon: IconButton(
                icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility,
                    size: 18),
                onPressed: () => setState(() => _obscure = !_obscure),
              ),
            ),
          ),
          if (_error != null) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppTheme.danger.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(_error!,
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.error, fontSize: 13)),
            ),
          ],
          const SizedBox(height: 20),
          SizedBox(
            height: 46,
            child: ElevatedButton(
              onPressed: _loading ? null : _login,
              child: _loading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white))
                  : const Text('Sign In'),
            ),
          ),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => const ForgotPasswordScreen(),
                ),
              );
            },
            child: Text(
              'Forgot Password?',
              style: TextStyle(
                color: Theme.of(context).colorScheme.primary,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RegisterForm extends StatefulWidget {
  final TabController tabController;
  final Function(String email, String password)? onAutoFill;
  const _RegisterForm({required this.tabController, this.onAutoFill});

  @override
  State<_RegisterForm> createState() => _RegisterFormState();
}

class _RegisterFormState extends State<_RegisterForm> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  final _course = TextEditingController();
  final _studentId = TextEditingController();
  final _address = TextEditingController();
  final _bio = TextEditingController();
  final _password = TextEditingController();
  final _nameFocus = FocusNode();
  final _emailFocus = FocusNode();
  final _phoneFocus = FocusNode();
  final _courseFocus = FocusNode();
  final _studentIdFocus = FocusNode();
  final _addressFocus = FocusNode();
  final _bioFocus = FocusNode();
  final _passwordFocus = FocusNode();
  String _userType = 'Student';
  String _yearLevel = '1st Year';
  String _department = 'Bachelor of Science in Industrial Engineering';
  bool _loading = false;
  bool _obscure = true;
  String? _error;
  String? _success;

  final _years = ['1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year'];
  final _userTypes = ['Student', 'Professor'];
  final _departments = [
    'Bachelor of Science in Electronics and Communication Engineering',
    'Bachelor of Science in Civil Engineering',
    'Bachelor of Science in Electrical Engineering',
    'Bachelor of Science in Mechanical Engineering',
    'Bachelor of Science in Aerospace Engineering',
    'Bachelor of Science in Computer Engineering',
    'Bachelor of Science in Industrial Engineering'
  ];

  @override
  void dispose() {
    for (final c in [
      _name,
      _email,
      _phone,
      _course,
      _studentId,
      _address,
      _bio,
      _password
    ]) {
      c.dispose();
    }
    for (final node in [
      _nameFocus,
      _emailFocus,
      _phoneFocus,
      _courseFocus,
      _studentIdFocus,
      _addressFocus,
      _bioFocus,
      _passwordFocus,
    ]) {
      node.dispose();
    }
    super.dispose();
  }

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _error = null;
    });

    final initials = _name.text
        .trim()
        .split(' ')
        .where((w) => w.isNotEmpty)
        .take(2)
        .map((w) => w[0].toUpperCase())
        .join();

    final account = UserAccount(
      id: _name.text
          .trim()
          .toLowerCase()
          .replaceAll(' ', '_')
          .replaceAll('.', '_')
          .replaceAll('@', '_'),
      name: _name.text.trim(),
      email: _email.text.trim(),
      phone: _phone.text.trim(),
      password: _password.text.trim(),
      userType: _userType,
      course: _course.text.trim(),
      yearLevel: _yearLevel,
      studentId: _studentId.text.trim(),
      address: _address.text.trim(),
      department: _department,
      avatarInitials: initials,
      bio: _bio.text.trim(),
    );

    // Store credentials before any state changes
    final email = _email.text.trim();
    final password = _password.text.trim();

    final ok = await AppStore().createAccount(account);
    if (!mounted) return;
    if (ok) {
      print('Account created successfully with email: $email');

      setState(() {
        _success = 'Account created successfully! You can now sign in.';
        _error = null;
        _loading = false;
      });

      // Trigger auto-fill using the parent's handler
      widget.onAutoFill?.call(email, password);

      // Clear the registration form after a delay
      Future.delayed(const Duration(milliseconds: 800), () {
        if (mounted) {
          print('Clearing registration form');
          _name.clear();
          _phone.clear();
          _course.clear();
          _studentId.clear();
          _address.clear();
          _bio.clear();
          setState(() {
            _userType = 'Student';
            _yearLevel = '1st Year';
          });
        }
      });
    } else {
      setState(() {
        _error = 'An account with this email already exists.';
        _success = null;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 16),
            _field(context, _name, 'Full Name', Icons.person_outline,
                focusNode: _nameFocus,
                textInputAction: TextInputAction.next,
                onFieldSubmitted: (_) =>
                    FocusScope.of(context).requestFocus(_emailFocus),
                validator: (v) => v!.isEmpty ? 'Required' : null),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: _userType,
              decoration: const InputDecoration(labelText: 'User Type'),
              items: _userTypes
                  .map((type) => DropdownMenuItem(
                      value: type,
                      child: Text(
                        type,
                        style: TextStyle(
                            fontSize: 13,
                            color: AppTheme.getTextPrimary(context)),
                      )))
                  .toList(),
              onChanged: (v) => setState(() => _userType = v!),
            ),
            const SizedBox(height: 12),
            _field(context, _email, 'Email', Icons.email_outlined,
                focusNode: _emailFocus,
                textInputAction: TextInputAction.next,
                onFieldSubmitted: (_) =>
                    FocusScope.of(context).requestFocus(_phoneFocus),
                keyboard: TextInputType.emailAddress,
                validator: (v) =>
                    v!.contains('@') ? null : 'Enter a valid email'),
            const SizedBox(height: 12),
            _field(context, _phone, 'Phone', Icons.phone_outlined,
                focusNode: _phoneFocus,
                textInputAction: TextInputAction.next,
                onFieldSubmitted: (_) =>
                    FocusScope.of(context).requestFocus(_courseFocus),
                keyboard: TextInputType.phone),
            const SizedBox(height: 9),
            DropdownButtonFormField<String>(
              initialValue: _department,
              decoration: const InputDecoration(
                labelText: 'Departments',
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
              isExpanded: true,
              items: _departments
                  .map((dept) => DropdownMenuItem(
                      value: dept,
                      child: Text(
                        dept,
                        style: TextStyle(
                            fontSize: 11,
                            color: AppTheme.getTextPrimary(context)),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 2,
                      )))
                  .toList(),
              onChanged: (v) => setState(() => _department = v ?? _department),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _field(
                      context, _studentId, 'Student ID', Icons.badge_outlined,
                      focusNode: _studentIdFocus,
                      textInputAction: TextInputAction.next,
                      onFieldSubmitted: (_) =>
                          FocusScope.of(context).requestFocus(_addressFocus)),
                ),
                const SizedBox(height: 7),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: _yearLevel,
                    decoration: const InputDecoration(labelText: 'Year Level'),
                    items: _years
                        .map((y) => DropdownMenuItem(
                            value: y,
                            child: Text(
                              y,
                              style: TextStyle(
                                  fontSize: 10,
                                  color: AppTheme.getTextPrimary(context)),
                            )))
                        .toList(),
                    onChanged: (v) => setState(() => _yearLevel = v!),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _field(context, _address, 'Address', Icons.location_on_outlined,
                focusNode: _addressFocus,
                textInputAction: TextInputAction.next,
                onFieldSubmitted: (_) =>
                    FocusScope.of(context).requestFocus(_bioFocus)),
            const SizedBox(height: 12),
            TextFormField(
              focusNode: _bioFocus,
              textInputAction: TextInputAction.next,
              onFieldSubmitted: (_) =>
                  FocusScope.of(context).requestFocus(_passwordFocus),
              style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
              controller: _bio,
              keyboardType: TextInputType.text,
              maxLines: 1,
              decoration: const InputDecoration(
                labelText: 'Short bio (optional)',
                prefixIcon: Icon(Icons.comment_outlined, size: 18),
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              focusNode: _passwordFocus,
              textInputAction: TextInputAction.done,
              onFieldSubmitted: (_) => _register(),
              style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
              controller: _password,
              obscureText: _obscure,
              validator: (v) => v!.isEmpty
                  ? 'Password is required'
                  : v.length < 6
                      ? 'Password must be at least 6 characters'
                      : null,
              decoration: InputDecoration(
                labelText: 'Password',
                prefixIcon: const Icon(Icons.lock_outline, size: 18),
                suffixIcon: IconButton(
                  icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility,
                      size: 18),
                  onPressed: () => setState(() => _obscure = !_obscure),
                ),
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Theme.of(context)
                      .colorScheme
                      .error
                      .withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(_error!,
                    style: TextStyle(color: AppTheme.danger, fontSize: 13)),
              ),
            ],
            if (_success != null) ...[
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.green.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(_success!,
                    style: const TextStyle(color: Colors.green, fontSize: 13)),
              ),
            ],
            const SizedBox(height: 20),
            SizedBox(
              height: 46,
              child: ElevatedButton(
                onPressed: _loading ? null : _register,
                child: _loading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Text('Create Account'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(BuildContext context, TextEditingController ctrl, String label,
      IconData icon,
      {TextInputType? keyboard,
      FocusNode? focusNode,
      TextInputAction? textInputAction,
      void Function(String)? onFieldSubmitted,
      String? Function(String?)? validator}) {
    return TextFormField(
      controller: ctrl,
      focusNode: focusNode,
      textInputAction: textInputAction,
      onFieldSubmitted: onFieldSubmitted,
      keyboardType: keyboard,
      validator: validator,
      style: TextStyle(color: AppTheme.getTextPrimary(context)),
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, size: 18),
      ),
    );
  }
}
